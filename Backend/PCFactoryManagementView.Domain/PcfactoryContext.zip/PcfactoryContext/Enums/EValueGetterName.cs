﻿namespace PCFactoryManagementView.Domain.PcfactoryContext.Enums
{
    public static class EValueGetterName
    {
        public const string IndicatorsValueGetter = "indicatorsValueGetter";
    }
}


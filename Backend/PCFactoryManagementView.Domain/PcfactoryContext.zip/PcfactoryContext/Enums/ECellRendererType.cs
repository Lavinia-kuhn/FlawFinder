﻿namespace PCFactoryManagementView.Domain.PcfactoryContext.Enums
{
    public enum ECellRendererType
    {
        Image,
        ValueInfo,
    }
}

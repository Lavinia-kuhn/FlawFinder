﻿namespace PCFactoryManagementView.Domain.PcfactoryContext.Enums
{
    public enum EDefaultCycleTime
    {
        SameValue = 1,
        Sum = 2,
        Average = 3
    }
}

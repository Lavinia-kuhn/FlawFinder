﻿
namespace PCFactoryManagementView.Domain.PcfactoryContext.Enums
{
    public enum EValueType
    {
        Decimal = 0,
        Integer = 1,
        TimeFormmat = 2,
        DecimalPercent = 3
    }
}

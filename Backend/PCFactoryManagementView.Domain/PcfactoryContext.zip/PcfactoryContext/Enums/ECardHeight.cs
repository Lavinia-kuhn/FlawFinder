﻿namespace PCFactoryManagementView.Domain.PcfactoryContext.Enums
{
    public enum ECardHeight
    {
        DEFAULT = 1,
        FULLCARD = 2
    }
}

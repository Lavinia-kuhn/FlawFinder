﻿namespace PCFactoryManagementView.Domain.PcfactoryContext.Enums
{
    public static class EAggregationFuncName
    {
        public const string IndicatorsAggFunc = "indicatorsAggFunc";
        public const string SUM = "sum";
        public const string AVG = "avg";
        public const string DETAILGROUP= "agGroupCellRenderer";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PCFactoryManagementView.Domain.PcfactoryContext.Enums
{
    public enum ETableOEEType
    {
        PEV = 1,
        MHD = 2
    }
}

﻿namespace PCFactoryManagementView.Domain.PcfactoryContext.Enums
{
    public enum EFilterType
    {
        CheckBox = 1,
        Radio = 2
    }
}

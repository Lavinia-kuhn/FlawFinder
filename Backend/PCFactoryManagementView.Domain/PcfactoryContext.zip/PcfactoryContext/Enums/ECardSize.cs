﻿namespace PCFactoryManagementView.Domain.PcfactoryContext.Enums
{
    public enum ECardSize
    {
        SMALL = 8,
        MEDIUM = 16,
        LARGE = 24
    }
}

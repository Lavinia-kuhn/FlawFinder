﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PCFactoryManagementView.Domain.PcfactoryContext.Enums
{
    public enum ETableLogisticsName
    {
        TBLINSPPPLANHD
    }
}

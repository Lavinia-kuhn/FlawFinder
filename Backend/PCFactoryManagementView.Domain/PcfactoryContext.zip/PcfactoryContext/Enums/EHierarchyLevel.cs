﻿namespace PCFactoryManagementView.Domain.PcfactoryContext.Enums
{
    public enum EHierarchyLevel
    {
        PLANT,
        AREA,
        SECTOR,
        MANAGERGRP,
        SUPLEVEL1,
        SUPLEVEL2,
        RESOURCE,
        PRODUCTIONEV
    }
}

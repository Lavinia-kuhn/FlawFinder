﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PCFactoryManagementView.Domain.PcfactoryContext.Enums
{
    public enum ETableManutName
    {
        TBLMOTICKET = 1,
        TBLMOHD = 2,
        TBLUSEREV = 3,
    }
}

﻿namespace PCFactoryManagementView.Domain.PcfactoryContext.Enums
{
    public enum ETableMovMatName
    {
        TBLMOVEV = 1,
        TBLMOVUN = 2,
        TBLFINALBALANCE = 3,
        TBLRESERVE = 4,
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PCFactoryManagementView.Domain.PcfactoryContext.Common.Entities
{
    public class Pie
    {
        public string type { get; set; }
        public double value { get; set; }
    }
}

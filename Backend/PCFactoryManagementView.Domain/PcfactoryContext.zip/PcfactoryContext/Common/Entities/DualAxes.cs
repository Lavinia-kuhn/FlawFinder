﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PCFactoryManagementView.Domain.PcfactoryContext.Common.Entities
{
    public class DualAxes
    {
        public string grouper { get; set; }
        public double value { get; set; }
        public double count { get; set; }
    }
}

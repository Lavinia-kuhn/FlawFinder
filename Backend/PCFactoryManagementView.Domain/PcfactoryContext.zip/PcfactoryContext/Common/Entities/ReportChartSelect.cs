﻿namespace PCFactoryManagementView.Domain.PcfactoryContext.Common.Entities
{
    public class ReportChartSelect
    {
        public string type { get; set; }
        public string label { get; set; }
    }

    public class IChartSelect
    {
        public string type { get; set; }
        public string label { get; set; }
    }
}

﻿using System.Collections.Generic;

namespace PCFactoryManagementView.Domain.PcfactoryContext.Common.Entities
{
    public class User
    {
        public int IdUser { get; set; }
        public string Code { get; set; }
        public string Password { get; set; }
    }
}

﻿namespace PCFactoryManagementView.Domain.PcfactoryContext.Common.Entities
{
    public class ReportFilterItem
    {
        public string label { get; set; }
        public string value { get; set; }
    }
}

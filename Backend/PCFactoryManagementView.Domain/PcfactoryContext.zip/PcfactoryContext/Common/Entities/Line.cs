﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PCFactoryManagementView.Domain.PcfactoryContext.Common.Entities
{
    public class Line
    {
        public string grouper { get; set; }
        public int value { get; set; }
    }
}

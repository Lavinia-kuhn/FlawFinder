﻿using System;

namespace PCFactoryManagementView.Domain.PcfactoryContext.Common.Queries
{
    public class UserQueryResult
    {
        public int UserId { get; set; }
        public string UserCode { get; set; }
    }
}

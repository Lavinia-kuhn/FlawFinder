﻿using System;

namespace PCFactoryManagementView.Domain.PcfactoryContext.Common.Queries
{
    public class RouteQueryResult
    {
        public int RouteId { get; set; }
        public string RouteCode { get; set; }
        public string RouteName { get; set; }

    }
}

﻿using System;

namespace PCFactoryManagementView.Domain.PcfactoryContext.Exceptions
{
    class TreeviewException : Exception
    {
        public TreeviewException(): base("TreeView")
        {

        }
    }
}

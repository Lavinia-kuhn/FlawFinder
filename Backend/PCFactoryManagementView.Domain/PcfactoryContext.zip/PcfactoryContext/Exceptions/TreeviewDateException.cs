﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PCFactoryManagementView.Domain.PcfactoryContext.Exceptions
{
    class TreeviewDateException : Exception
    {
        public TreeviewDateException(): base("TreeViewDate")
        {

        }
    }
}
